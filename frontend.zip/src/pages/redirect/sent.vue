<template>
    <div>Sent</div>
</template>
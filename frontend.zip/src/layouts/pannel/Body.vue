<template>
    <div class="pannel--body" >
        <slot />
    </div>
</template>

<script setup>

</script>
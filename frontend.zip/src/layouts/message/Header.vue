<template>
    <div>Redirect Header</div>
</template>
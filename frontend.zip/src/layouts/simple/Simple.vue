<template>
  <div>
    <div>Auth<router-view /></div>
  </div>
</template>
<script setup>

</script>
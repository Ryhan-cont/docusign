<template>
  <div>
    <router-view />  
  </div>
</template>